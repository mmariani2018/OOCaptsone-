﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mariani.Capstone
{
    class ConvertMetricToEnglish
    {
        private int miles;
        private int feet;
        private int yards;
        private double inches;

        public ConvertMetricToEnglish(string userMeters, string userKilometers, string userCentimeters)
        {
            int totalMeters = kilometersToMeters(int.Parse(userKilometers)) + int.Parse(userMeters);

            int centimeters = metersToCentimeters(totalMeters) + int.Parse(userCentimeters);

            inches = centimetersToInches(centimeters);

            feet = inchesToFeet(inches);

            yards = feetToYards(feet);

            miles = yardsToMiles(yards);
        }
        public string getMiles()
        {
            return Convert.ToString(miles);
        }
        public string getFeet()
        {
            return Convert.ToString(feet);
        }
        public string getYards()
        {
            return Convert.ToString(yards);
        }
        public string getInches()
        {
            return Convert.ToString(inches);
        }
        private int kilometersToMeters(int kilometers)
        {
            return kilometers * 1000;
        }

        private int metersToCentimeters(int meters)
        {
            return meters * 100;
        }

        private double centimetersToInches(int centimeters)
        {
            Rounding round = new Rounding();
            double totalCentimeter = centimeters / 2.54;

            return round.Round(totalCentimeter);
        }
        private int inchesToFeet(double inches)
        {
            return (int)inches / 12;
        }

        private int feetToYards(int feet)
        {
            return feet / 3;
        }

        private int yardsToMiles(int yards)
        {
            return yards / 1760;
        }
    }
}
