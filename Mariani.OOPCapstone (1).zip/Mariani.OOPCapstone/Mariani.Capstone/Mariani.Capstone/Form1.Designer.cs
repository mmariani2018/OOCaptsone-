﻿namespace Mariani.Capstone
{
    partial class frmConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radEnglishToMetric = new System.Windows.Forms.RadioButton();
            this.radMetricToEnglish = new System.Windows.Forms.RadioButton();
            this.grpEnglishToMetric = new System.Windows.Forms.GroupBox();
            this.txtInches = new System.Windows.Forms.TextBox();
            this.txtFeet = new System.Windows.Forms.TextBox();
            this.txtYards = new System.Windows.Forms.TextBox();
            this.txtMiles = new System.Windows.Forms.TextBox();
            this.lblInches = new System.Windows.Forms.Label();
            this.lblMiles = new System.Windows.Forms.Label();
            this.lblFeet = new System.Windows.Forms.Label();
            this.lblYards = new System.Windows.Forms.Label();
            this.grpMetricToEnglish = new System.Windows.Forms.GroupBox();
            this.txtCentimeter = new System.Windows.Forms.TextBox();
            this.txtMeter = new System.Windows.Forms.TextBox();
            this.txtKilometer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblKilometer = new System.Windows.Forms.Label();
            this.lblCentimeter = new System.Windows.Forms.Label();
            this.lblMeter = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.grpEnglishToMetric.SuspendLayout();
            this.grpMetricToEnglish.SuspendLayout();
            this.SuspendLayout();
            // 
            // radEnglishToMetric
            // 
            this.radEnglishToMetric.AutoSize = true;
            this.radEnglishToMetric.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radEnglishToMetric.Location = new System.Drawing.Point(76, 38);
            this.radEnglishToMetric.Name = "radEnglishToMetric";
            this.radEnglishToMetric.Size = new System.Drawing.Size(173, 29);
            this.radEnglishToMetric.TabIndex = 3;
            this.radEnglishToMetric.Text = "English to Metric";
            this.radEnglishToMetric.UseVisualStyleBackColor = true;
            this.radEnglishToMetric.CheckedChanged += new System.EventHandler(this.radEnglishToMetric_CheckedChanged);
            // 
            // radMetricToEnglish
            // 
            this.radMetricToEnglish.AutoSize = true;
            this.radMetricToEnglish.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radMetricToEnglish.Location = new System.Drawing.Point(484, 38);
            this.radMetricToEnglish.Name = "radMetricToEnglish";
            this.radMetricToEnglish.Size = new System.Drawing.Size(173, 29);
            this.radMetricToEnglish.TabIndex = 4;
            this.radMetricToEnglish.Text = "Metric to English";
            this.radMetricToEnglish.UseVisualStyleBackColor = true;
            this.radMetricToEnglish.CheckedChanged += new System.EventHandler(this.radMetricToEnglish_CheckedChanged);
            // 
            // grpEnglishToMetric
            // 
            this.grpEnglishToMetric.Controls.Add(this.txtInches);
            this.grpEnglishToMetric.Controls.Add(this.txtFeet);
            this.grpEnglishToMetric.Controls.Add(this.txtYards);
            this.grpEnglishToMetric.Controls.Add(this.txtMiles);
            this.grpEnglishToMetric.Controls.Add(this.lblInches);
            this.grpEnglishToMetric.Controls.Add(this.lblMiles);
            this.grpEnglishToMetric.Controls.Add(this.lblFeet);
            this.grpEnglishToMetric.Controls.Add(this.lblYards);
            this.grpEnglishToMetric.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpEnglishToMetric.Location = new System.Drawing.Point(76, 85);
            this.grpEnglishToMetric.Name = "grpEnglishToMetric";
            this.grpEnglishToMetric.Size = new System.Drawing.Size(232, 272);
            this.grpEnglishToMetric.TabIndex = 5;
            this.grpEnglishToMetric.TabStop = false;
            this.grpEnglishToMetric.Text = "English to Metric";
            // 
            // txtInches
            // 
            this.txtInches.Location = new System.Drawing.Point(31, 215);
            this.txtInches.Name = "txtInches";
            this.txtInches.Size = new System.Drawing.Size(100, 27);
            this.txtInches.TabIndex = 13;
            // 
            // txtFeet
            // 
            this.txtFeet.Location = new System.Drawing.Point(31, 162);
            this.txtFeet.Name = "txtFeet";
            this.txtFeet.Size = new System.Drawing.Size(100, 27);
            this.txtFeet.TabIndex = 12;
            // 
            // txtYards
            // 
            this.txtYards.Location = new System.Drawing.Point(31, 105);
            this.txtYards.Name = "txtYards";
            this.txtYards.Size = new System.Drawing.Size(100, 27);
            this.txtYards.TabIndex = 11;
            // 
            // txtMiles
            // 
            this.txtMiles.Location = new System.Drawing.Point(31, 53);
            this.txtMiles.Name = "txtMiles";
            this.txtMiles.Size = new System.Drawing.Size(100, 27);
            this.txtMiles.TabIndex = 10;
            // 
            // lblInches
            // 
            this.lblInches.AutoSize = true;
            this.lblInches.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInches.Location = new System.Drawing.Point(162, 222);
            this.lblInches.Name = "lblInches";
            this.lblInches.Size = new System.Drawing.Size(57, 20);
            this.lblInches.TabIndex = 9;
            this.lblInches.Text = "Inches";
            // 
            // lblMiles
            // 
            this.lblMiles.AutoSize = true;
            this.lblMiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiles.Location = new System.Drawing.Point(162, 56);
            this.lblMiles.Name = "lblMiles";
            this.lblMiles.Size = new System.Drawing.Size(45, 20);
            this.lblMiles.TabIndex = 6;
            this.lblMiles.Text = "Miles";
            // 
            // lblFeet
            // 
            this.lblFeet.AutoSize = true;
            this.lblFeet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeet.Location = new System.Drawing.Point(162, 169);
            this.lblFeet.Name = "lblFeet";
            this.lblFeet.Size = new System.Drawing.Size(42, 20);
            this.lblFeet.TabIndex = 8;
            this.lblFeet.Text = "Feet";
            // 
            // lblYards
            // 
            this.lblYards.AutoSize = true;
            this.lblYards.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYards.Location = new System.Drawing.Point(162, 108);
            this.lblYards.Name = "lblYards";
            this.lblYards.Size = new System.Drawing.Size(51, 20);
            this.lblYards.TabIndex = 7;
            this.lblYards.Text = "Yards";
            // 
            // grpMetricToEnglish
            // 
            this.grpMetricToEnglish.Controls.Add(this.txtCentimeter);
            this.grpMetricToEnglish.Controls.Add(this.txtMeter);
            this.grpMetricToEnglish.Controls.Add(this.txtKilometer);
            this.grpMetricToEnglish.Controls.Add(this.label1);
            this.grpMetricToEnglish.Controls.Add(this.lblKilometer);
            this.grpMetricToEnglish.Controls.Add(this.lblCentimeter);
            this.grpMetricToEnglish.Controls.Add(this.lblMeter);
            this.grpMetricToEnglish.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMetricToEnglish.Location = new System.Drawing.Point(484, 85);
            this.grpMetricToEnglish.Name = "grpMetricToEnglish";
            this.grpMetricToEnglish.Size = new System.Drawing.Size(243, 209);
            this.grpMetricToEnglish.TabIndex = 6;
            this.grpMetricToEnglish.TabStop = false;
            this.grpMetricToEnglish.Text = "Metric to English";
            this.grpMetricToEnglish.Enter += new System.EventHandler(this.grpMetricToEnglish_Enter);
            // 
            // txtCentimeter
            // 
            this.txtCentimeter.Location = new System.Drawing.Point(31, 162);
            this.txtCentimeter.Name = "txtCentimeter";
            this.txtCentimeter.Size = new System.Drawing.Size(100, 27);
            this.txtCentimeter.TabIndex = 12;
            // 
            // txtMeter
            // 
            this.txtMeter.Location = new System.Drawing.Point(31, 105);
            this.txtMeter.Name = "txtMeter";
            this.txtMeter.Size = new System.Drawing.Size(100, 27);
            this.txtMeter.TabIndex = 11;
            // 
            // txtKilometer
            // 
            this.txtKilometer.Location = new System.Drawing.Point(31, 53);
            this.txtKilometer.Name = "txtKilometer";
            this.txtKilometer.Size = new System.Drawing.Size(100, 27);
            this.txtKilometer.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(162, 222);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 9;
            // 
            // lblKilometer
            // 
            this.lblKilometer.AutoSize = true;
            this.lblKilometer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKilometer.Location = new System.Drawing.Point(151, 56);
            this.lblKilometer.Name = "lblKilometer";
            this.lblKilometer.Size = new System.Drawing.Size(75, 20);
            this.lblKilometer.TabIndex = 6;
            this.lblKilometer.Text = "Kilometer";
            // 
            // lblCentimeter
            // 
            this.lblCentimeter.AutoSize = true;
            this.lblCentimeter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCentimeter.Location = new System.Drawing.Point(151, 165);
            this.lblCentimeter.Name = "lblCentimeter";
            this.lblCentimeter.Size = new System.Drawing.Size(87, 20);
            this.lblCentimeter.TabIndex = 8;
            this.lblCentimeter.Text = "Centimeter";
            // 
            // lblMeter
            // 
            this.lblMeter.AutoSize = true;
            this.lblMeter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMeter.Location = new System.Drawing.Point(151, 105);
            this.lblMeter.Name = "lblMeter";
            this.lblMeter.Size = new System.Drawing.Size(50, 20);
            this.lblMeter.TabIndex = 7;
            this.lblMeter.Text = "Meter";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(76, 408);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(255, 68);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnConvert
            // 
            this.btnConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConvert.Location = new System.Drawing.Point(484, 408);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(255, 68);
            this.btnConvert.TabIndex = 8;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(264, 522);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(255, 68);
            this.btnReset.TabIndex = 9;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // frmConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(858, 646);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpMetricToEnglish);
            this.Controls.Add(this.grpEnglishToMetric);
            this.Controls.Add(this.radMetricToEnglish);
            this.Controls.Add(this.radEnglishToMetric);
            this.Name = "frmConverter";
            this.Text = " ";
            this.Load += new System.EventHandler(this.frmConverter_Load);
            this.grpEnglishToMetric.ResumeLayout(false);
            this.grpEnglishToMetric.PerformLayout();
            this.grpMetricToEnglish.ResumeLayout(false);
            this.grpMetricToEnglish.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radEnglishToMetric;
        private System.Windows.Forms.RadioButton radMetricToEnglish;
        private System.Windows.Forms.GroupBox grpEnglishToMetric;
        private System.Windows.Forms.Label lblInches;
        private System.Windows.Forms.Label lblMiles;
        private System.Windows.Forms.Label lblFeet;
        private System.Windows.Forms.Label lblYards;
        private System.Windows.Forms.TextBox txtInches;
        private System.Windows.Forms.TextBox txtFeet;
        private System.Windows.Forms.TextBox txtYards;
        private System.Windows.Forms.TextBox txtMiles;
        private System.Windows.Forms.GroupBox grpMetricToEnglish;
        private System.Windows.Forms.TextBox txtCentimeter;
        private System.Windows.Forms.TextBox txtMeter;
        private System.Windows.Forms.TextBox txtKilometer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblKilometer;
        private System.Windows.Forms.Label lblCentimeter;
        private System.Windows.Forms.Label lblMeter;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnReset;
    }
}

