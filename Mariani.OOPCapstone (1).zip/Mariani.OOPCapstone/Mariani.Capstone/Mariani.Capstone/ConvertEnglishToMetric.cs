﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mariani.Capstone
{
    class ConvertEnglishToMetric
    {
        private int kilometer;
        private int meters;
        private double centimeters;

        public ConvertEnglishToMetric(string userMiles, string userYards, string userFeet, string userInches)
        {

            int totalFeet = yardsToFeet(milesToYards(int.Parse(userMiles)) + Convert.ToInt16(userYards)) + int.Parse(userFeet);

            double totalInches = feetToInches(totalFeet) + int.Parse(userInches);

            centimeters = inchesToCentimeters(totalInches);

            meters = centimetersToMeters(centimeters);

            kilometer = metersToKilometers(meters);

        }

        public String getKilometers()
        {
            return Convert.ToString(kilometer);
        }
        public String getMeters()
        {
            return Convert.ToString(meters);
        }
        public String getCentimeters()
        {
            return Convert.ToString(centimeters);
        }
        public int milesToYards(int miles)
        {
            return miles * 1760;
        }

        public int yardsToFeet(int yards)
        {
            return yards * 3;
        }

        public double feetToInches(int feet)
        {
            return feet * 12;
        }

        public double inchesToCentimeters(double inches)
        {
            Rounding round = new Rounding();
            double totalInches = inches * 2.54;
            return round.Round(totalInches);
        }

        public int centimetersToMeters(double centimeters)
        {
            return (int)centimeters / 100;
        }

        public int metersToKilometers(int meters)
        {
            return meters / 1000;
        }
    }
}
