﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mariani.Capstone
{
    public partial class frmConverter : Form
    {
        public frmConverter()
        {
            InitializeComponent();
        }

        private void radEnglishToMetric_CheckedChanged(object sender, EventArgs e)
        {
            grpEnglishToMetric.Visible = true;
            grpEnglishToMetric.Enabled = true;
            grpMetricToEnglish.Visible = true;
            grpMetricToEnglish.Enabled = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void validateInputs()
        {
            if (txtInches.Text == "")
                txtInches.Text = "0";

            if (txtFeet.Text == "")
                txtFeet.Text = "0";

            if (txtMiles.Text == "")
                txtMiles.Text = "0";

            if (txtYards.Text == "")
                txtYards.Text = "0";
        }
        void validateOtherInputs()
        {
            if (txtKilometer.Text == "")
                txtKilometer.Text = "0";

            if (txtMeter.Text == "")
                txtMeter.Text = "0";

            if (txtCentimeter.Text == "")
                txtCentimeter.Text = "0";
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (radEnglishToMetric.Checked)
            {
                validateInputs();

                ConvertEnglishToMetric metric = new ConvertEnglishToMetric(txtMiles.Text, txtYards.Text, txtFeet.Text, txtInches.Text);

                txtCentimeter.Text = metric.getCentimeters();
                txtMeter.Text = metric.getMeters();
                txtKilometer.Text = metric.getKilometers();
                 
            }
            else
            {
                validateOtherInputs();

                ConvertMetricToEnglish english = new ConvertMetricToEnglish(txtMeter.Text, txtKilometer.Text, txtCentimeter.Text);

                txtInches.Text = english.getInches();
                txtFeet.Text = english.getFeet();
                txtYards.Text = english.getYards();
                txtMiles.Text = english.getMiles();

            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //Application.Restart();
            txtKilometer.Clear();
            txtMeter.Clear();
            txtCentimeter.Clear();
            txtMiles.Clear();
            txtFeet.Clear();
            txtInches.Clear();
            txtYards.Clear();
        }

        private void grpMetricToEnglish_Enter(object sender, EventArgs e)
        {

        }

        private void radMetricToEnglish_CheckedChanged(object sender, EventArgs e)
        {
            grpMetricToEnglish.Visible = true;
            grpMetricToEnglish.Enabled = true;
            grpEnglishToMetric.Visible = true;
            grpEnglishToMetric.Enabled = false;
        }

        private void frmConverter_Load(object sender, EventArgs e)
        {
            grpMetricToEnglish.Enabled = false;
            grpEnglishToMetric.Enabled = false;
        }
    }
}
